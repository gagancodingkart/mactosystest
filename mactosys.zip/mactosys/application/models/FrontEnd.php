<?php
class FrontEnd extends CI_Model { 

    public function abcd()
    {
        
        $data["kshetraList"]=$this->db->select('id,kshetra_name')->from('kshetra')->get()->result();
                
            return $data;
             
    }
    public function userRegister($userDetail)
    {
     $count=$this->db->select('count(*) as count')->from('user')->where('id',$userDetail['id'])->get()->result();
     
    if(!$count[0]->count>0){
        $date  =date('Y-m-d H:i:s');
        $data  = array(
                    'id' => $userDetail['id'],
                    'name' => $userDetail['given_name'],
                    'image' => $userDetail['picture'],
                    'email' => $userDetail['email'],
                    'register_at' => $date
                );
        $result = $this->db->insert('user', $data);
        if($result){
            return "<p class='bg-success text-white text-center'>user Added Successfully!</p>";
        }else{
            return $result;
        }         
    }
   }
   public function postRegister($userDetail)
    {
        $date  =date('Y-m-d H:i:s');
        $data  = array(
                    'user_id' 	  => $userDetail['gid'],
                    'discription' => $userDetail['description'],
                    'posted_at'   => $date
                );
        $result = $this->db->insert('post', $data);
        if($result){
            return "<p class='bg-success text-white text-center'>past Added Successfully!</p>";
        }else{
            return $result;
        }         

   }
}
?>