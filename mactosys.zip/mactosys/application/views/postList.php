<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
					<div class="table-responsive">
						
						<table id="kshetra-table" class="table table-bordered table-head-fixed table-striped dataTable dtr-inline" role="grid">
								<thead>
									<tr role="row">
										<th>User image</th>
										<th>name </th>
										<th>discription </th>
										<th>Posted at </th>
									</tr>
								</thead>
								<tbody>
									<?php
									$news = $this->db->query("SELECT user.name,user.image,post.discription,post.posted_at from post, user where user.id=post.user_id")->result_array();
								
									$count = 0;
									foreach($news as $row):
										$count++;
									?>
									<tr role="row" class="even">
										<td tabindex="0" class="sorting_1"><img src="<?= $row['image']?>"/></td><td tabindex="0" class="sorting_1"><?= $row['name']?></td>
										<td style="text-align:center"><?= $row['discription']?></td>
										<td style="text-align:center"><?= $row['posted_at']?></td>
										
									</tr>
									<?php
									endforeach;
									?>
								</tbody>
							</table>
					</div>